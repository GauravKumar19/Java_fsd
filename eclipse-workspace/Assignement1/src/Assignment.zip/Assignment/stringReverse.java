package Assignment;
import java.util.*;

public class stringReverse {
// without built in function
	
	public static void main(String[] args) {
		 
		Scanner sc = new Scanner(System.in); 
		
	String str1 = "Hello Welcome to Java World!!";
	
	for (int i=str1.length();i>0;i--) {
		System.out.print(str1.charAt(i-1));
	}
	
// With built-in function	
	
	
		
	}
}
